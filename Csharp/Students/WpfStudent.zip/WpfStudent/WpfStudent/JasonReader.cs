﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Json;

namespace MVVM
{
    public class JsonFileReader : OpenWriteCalled
    {
        public List<Student> Open(string filename)
        {
            List<Student> students = new List<Student>();
            DataContractJsonSerializer jsonFormatter =
                new DataContractJsonSerializer(typeof(List<Student>));
            using (FileStream fs = new FileStream(filename, FileMode.OpenOrCreate))
            {
                students = jsonFormatter.ReadObject(fs) as List<Student>;
            }

            return students;
        }

        public void Save(string filename, List<Student> studentList)
        {
            DataContractJsonSerializer jsonFormatter =
                new DataContractJsonSerializer(typeof(List<Student>));
            using (FileStream fs = new FileStream(filename, FileMode.Create))
            {
                jsonFormatter.WriteObject(fs, studentList);
            }
        }
    }
}
