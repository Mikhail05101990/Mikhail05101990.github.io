﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Runtime.CompilerServices;
using System.IO;


namespace MVVM
{

    public class MainVM : INotifyPropertyChanged
    {
        private Student selectedStudent;
        private ObservableCollection<Student> students = new ObservableCollection<Student>();
        private HtmlFileReader HtmlReader;
        private JsonFileReader JsonReader;
        private PathPicked PickedFile;

        public MainVM(PathPicked PickedFile, HtmlFileReader HtmlReader, JsonFileReader JsonReader)
        {
            this.PickedFile = PickedFile;
            this.HtmlReader = HtmlReader;
            this.JsonReader = JsonReader;

            FileInfo fileInfo = new FileInfo(AppDomain.CurrentDomain.BaseDirectory + @"\Students.xml");
            if (fileInfo.Exists)
            {
                var students = HtmlReader.Open(AppDomain.CurrentDomain.BaseDirectory + @"\Students.xml");
                foreach (var p in students)
                    Students.Add(p);
            }

        }

        public ObservableCollection<Student> Students
        {
            get { return students; }
            set { students = value; }
        }

        public Student SelectedStudent
        {
            get { return selectedStudent; }
            set
            {
                selectedStudent = value;
                OnPropertyChanged("SelectedStudent");
            }
        }

        private RelayCommand newStudentCommand;
        public RelayCommand NewStudentCommand
        {
            get
            {
                return newStudentCommand ??
                  (newStudentCommand = new RelayCommand(obj =>
                  {
                      StudentViewModel stVM;
                      if (selectedStudent != null)
                      {
                          stVM = new StudentViewModel(selectedStudent, students, true);
                      } else
                      {
                          stVM = new StudentViewModel(new Student(), students, true);
                      }
                      NewStudentDialog w1 = new NewStudentDialog(stVM);
                      w1.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
                      w1.ShowDialog();
                  }));
            }
        }

        private RelayCommand editWindowShowCommand;
        public RelayCommand EditWindowShowCommand
        {
            get
            {
                return editWindowShowCommand ??
                  (editWindowShowCommand = new RelayCommand(obj =>
                  {
                      if (selectedStudent!=null)
                      {
                          StudentViewModel stVM = new StudentViewModel(selectedStudent, students, false);
                          NewStudentDialog w1 = new NewStudentDialog(stVM);
                          w1.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
                          w1.ShowDialog();
                      }
                  }));
            }
        }

        private RelayCommand removeCommand;
        public RelayCommand RemoveCommand
        {
            get
            {
                return removeCommand ??
                  (removeCommand = new RelayCommand(obj =>
                  {
                      if (SelectedStudent != null)
                      {
                          
                          if (PickedFile.Dialog())
                          {
                              Collection<object> b = (Collection<object>)obj;
                              List<Student> list = b.Cast<Student>().ToList();
                              list.ForEach(std => Students.Remove(std));
                              PickedFile.ShowMessage("Выбранные студенты удалены");
                          }
                      }
                  }));
            }
        }

        private RelayCommand saveJsCommand;
        public RelayCommand SaveJsCommand
        {
            get
            {
                return saveJsCommand ??
                  (saveJsCommand = new RelayCommand(obj =>
                  {
                      try
                      {
                          if (PickedFile.SaveFileDialog() == true)
                          {
                              JsonReader.Save(PickedFile.FilePath, Students.ToList());
                              PickedFile.ShowMessage("Файл сохранен");
                          }
                      }
                      catch (Exception ex)
                      {
                          PickedFile.ShowMessage(ex.Message);
                      }
                  }));
            }
        }
        private RelayCommand saveHtmlCommand;
        public RelayCommand SaveHtmlCommand
        {
            get
            {
                return saveHtmlCommand ??
                  (saveHtmlCommand = new RelayCommand(obj =>
                  {
                      try
                      {
                          if (PickedFile.SaveFileDialog() == true)
                          {
                              HtmlReader.Save(PickedFile.FilePath, Students.ToList());
                              PickedFile.ShowMessage("Файл сохранен");
                          }
                      }
                      catch (Exception ex)
                      {
                          PickedFile.ShowMessage(ex.Message);
                      }
                  }));
            }
        }
        private RelayCommand openJsCommand;
        public RelayCommand OpenJsCommand
        {
            get
            {
                return openJsCommand ??
                  (openJsCommand = new RelayCommand(obj =>
                  {
                      try
                      {
                          if (PickedFile.OpenFileDialog() == true)
                          {
                              var students = JsonReader.Open(PickedFile.FilePath);
                              Students.Clear();
                              foreach (var p in students)
                                  Students.Add(p);
                              PickedFile.ShowMessage("Файл открыт");
                          }
                      }
                      catch (Exception ex)
                      {
                          PickedFile.ShowMessage(ex.Message);
                      }
                  }));
            }
        }
        private RelayCommand openHtmlCommand;
        public RelayCommand OpenHtmlCommand
        {
            get
            {
                return openHtmlCommand ??
                  (openHtmlCommand = new RelayCommand(obj =>
                  {
                      try
                      {
                          if (PickedFile.OpenFileDialog() == true)
                          {
                              var students = HtmlReader.Open(PickedFile.FilePath);
                              Students.Clear();
                              foreach (var p in students)
                                  Students.Add(p);
                              PickedFile.ShowMessage("Файл открыт");
                          }
                      }
                      catch (Exception ex)
                      {
                          PickedFile.ShowMessage(ex.Message);
                      }
                  }));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName]string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}
