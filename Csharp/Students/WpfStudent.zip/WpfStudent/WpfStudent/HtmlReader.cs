﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections.ObjectModel;

namespace MVVM
{
    public class HtmlFileReader : OpenWriteCalled
    {
        public List<Student> Open(string filename)
        {
            List<Student> students = new List<Student>();
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Student>), new XmlRootAttribute("Students"));

            using (FileStream fs = new FileStream(filename, FileMode.OpenOrCreate))
            {
                students = (List<Student>)xmlSerializer.Deserialize(fs);
            }
            return students;
        }

        public void Save(string filename, List<Student> studentList)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Student>), new XmlRootAttribute("Students"));
            using (FileStream fs = new FileStream(filename, FileMode.OpenOrCreate))
            {
                xmlSerializer.Serialize(fs, studentList);
            }
        }
    }
    public class StudentItem
    {
        public string FirstName;
        public string Last;
        public int Age;
        public bool Gender;
    }
}
