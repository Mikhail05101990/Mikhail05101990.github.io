﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Runtime.CompilerServices;
using System.Collections.ObjectModel;

namespace MVVM
{


    public class Reader
    {
        private int counter = 0;
        private int nmStud = 0;
        private Char[] delimiter = { '"', '>', '<' };
        private string line;
        private ObservableCollection<Student> students = new ObservableCollection<Student>();
        private string pyt = AppDomain.CurrentDomain.BaseDirectory + @"\Students.xml";
        private string[] s1;

        private string firstName = string.Empty;
        private string lastName = string.Empty;
        private int age;
        private bool gender;

        public ObservableCollection<Student> LoadStudents()
        {
        System.IO.StreamReader file =
                new System.IO.StreamReader(pyt);
            while ((line = file.ReadLine()) != null)
            {
                if (counter < 2)
                {
                    counter++;
                    continue;
                }
                if (line != "</Students>")
                {
                    s1 = line.Split(delimiter, StringSplitOptions.RemoveEmptyEntries);

                    if (nmStud == 0)
                    {
                        counter++;
                        nmStud++;
                        continue;
                    }
                    if (nmStud == 1)
                    {
                        line = s1[2];
                        firstName = line;
                        counter++;
                        nmStud++;
                        continue;
                    }
                    if (nmStud == 2)
                    {
                        line = s1[2];
                        lastName = line;
                        counter++;
                        nmStud++;
                        continue;
                    }
                    if (nmStud == 3)
                    {
                        line = s1[2];
                        age = Convert.ToInt32(line);
                        counter++;
                        nmStud++;
                        continue;
                    }
                    if (nmStud == 4)
                    {
                        line = s1[2];
                        if (line != "0")
                        { gender = false; }
                        else { gender = true; }
                        students.Add(new Student { FirstName = firstName, Last = lastName, Age = age, Gender = gender });
                        counter++;
                        nmStud++;
                        continue;
                    }
                    if (nmStud == 5)
                    {
                        counter++;
                        nmStud=0;
                    }
                }
            }
            file.Close();
            return students;
        }
    }
}
