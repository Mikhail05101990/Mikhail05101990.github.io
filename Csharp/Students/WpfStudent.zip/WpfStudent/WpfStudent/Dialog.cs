﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;
using System.Windows;
using System.Collections.ObjectModel;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Input;

namespace MVVM
{
    public interface FilePickedInterface
    {
        void ShowMessage(string message);   
        string FilePath { get; set; }   
        bool OpenFileDialog(); 
        bool SaveFileDialog();  
    }
    public class PathPicked : FilePickedInterface
    {
        public string FilePath { get; set; }

        public bool OpenFileDialog()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                FilePath = openFileDialog.FileName;
                return true;
            }
            return false;
        }
        public bool SaveFileDialog()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            if (saveFileDialog.ShowDialog() == true)
            {
                FilePath = saveFileDialog.FileName;
                return true;
            }
            return false;
        }
        public void ShowMessage(string message)
        {
            MessageBox.Show(message);
        }
        public bool Dialog()
        {
            MessageBoxResult message = MessageBox.Show("Вы действительно хотите удалить выбранных студентов?", "Операция удаления", MessageBoxButton.OKCancel);
            if (message == MessageBoxResult.OK)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    public interface OpenWriteCalled
    {
        List<Student> Open(string filename);
        void Save(string filename, List<Student> StudentList);
    }
    public interface MessageClass
    {
        void ShowMessage(string message);
    }
    public class Message : MessageClass
    {
        public void ShowMessage(string message)
        {
            MessageBox.Show(message);
        }
    }







}
