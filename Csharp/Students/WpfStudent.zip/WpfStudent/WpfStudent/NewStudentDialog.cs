﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace MVVM
{
    public partial class NewStudentDialog : Window
    {
        public NewStudentDialog(StudentViewModel VM)
        {
            InitializeComponent();
            DataContext = VM;
            Closed += (o, args) => BindableDialogResult = DialogResult;
            SetBinding(BindableDialogResultProperty, new Binding("DialogResult"));
        }

        void OnYes(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }
        void closed(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
        public bool? BindableDialogResult
        {
            get { return (bool?)GetValue(BindableDialogResultProperty); }
            set { SetValue(BindableDialogResultProperty, value); }
        }

        public static readonly DependencyProperty BindableDialogResultProperty =
            DependencyProperty.Register("BindableDialogResult", typeof(bool?), typeof(NewStudentDialog),
                new FrameworkPropertyMetadata(
                    null,
                    FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));
    }
}

