﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Runtime.CompilerServices;


namespace MVVM
{
    public class Student : INotifyPropertyChanged
    {
        private string first;
        private string last;
        private int age;
        private bool? gender;

        public string FirstName
        {
            get { return first; }
            set
            {
                if (value != "")
                {
                    first = value;
                    OnPropertyChanged("FirstName");
                }
                
            }
        }
        public string Last
        {
            get { return last; }
            set
            {
                if (value != "")
                {
                    last = value;
                    OnPropertyChanged("Last");
                }

            }
        }
        public int Age
        {
            get { return age; }
            set
            {
                if (value >= 16 & value <=100)
                {
                    age = value;
                    OnPropertyChanged("Age");
                }
                
            }
        }
        public bool? Gender
        {
            get { return gender; }
            set
            {
                gender = value;
                OnPropertyChanged("Gender");
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName]string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }


    
}
