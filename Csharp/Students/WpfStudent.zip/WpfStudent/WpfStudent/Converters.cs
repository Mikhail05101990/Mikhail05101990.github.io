﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Windows.Data;

namespace MVVM
{
    public class AgeConverter : IValueConverter
    {
        int[] rest = new int[4];
        string text;

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string bit = " лет";
            int age = (int)value;
            rest[0] = (age + 9) % 10;
            rest[1] = (age + 8) % 10;
            rest[2] = (age + 7) % 10;
            rest[3] = (age + 6) % 10;
            if (rest[0] == 0)
                bit = " год";
            if (rest[1] == 0 || rest[2] == 0 || rest[3] == 0)
                bit = " года";
            text = age.ToString() + bit;
            return text;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
    public class GenderConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool gender = (bool)value;
            
            if (gender) return "Woman"; else return "Men";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}