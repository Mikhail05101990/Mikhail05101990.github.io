﻿using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Collections.ObjectModel;

namespace MVVM
{
    public class StudentViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Student> students;
        private bool? dialogResult = null;
        Student student;
        Message MS = new Message();
        private string firstName;
        private string lastName;
        private int age;
        private bool? gender = null;
        private bool act;


        public StudentViewModel(Student s, ObservableCollection<Student> students, bool bl)
        {
            firstName = s.FirstName;
            lastName = s.Last;
            age = s.Age;
            gender = s.Gender;
            act = bl;
            student = s;
            this.students = students;
        }

        public string FirstName
        {
            get { return firstName; }
            set
            {
                    firstName = value;
            }
        }
        public string Last
        {
            get { return lastName; }
            set
            {
                    lastName = value;
            }
        }
        public int Age
        {
            get { return age; }
            set
            {
                    age = value;
            }
        }
        public bool? Gender
        {
            get { return gender; }
            set
            {
                    gender = value;
            }
        }
        private RelayCommand pickMen;
        public RelayCommand PickMen
        {
            get
            {
                return pickMen ??
                  (pickMen = new RelayCommand(obj =>
                  {
                      gender = false;
                  }));
            }
        }
        private RelayCommand pickWoman;
        public RelayCommand PickWoman
        {
            get
            {
                return pickWoman ??
                  (pickWoman = new RelayCommand(obj =>
                  {
                      gender = true;
                  }));
            }
        }
        private bool checkValues()
        {
            bool b1 = true;
            if (firstName == "")
            {
                MS.ShowMessage("The field First name can not be empty");
                b1 = false;
            }
            if (lastName == "")
            {
                MS.ShowMessage("The field Last name can not be empty");
                b1 = false;
            }
            if (age > 0)
            {
                if (age <16)
                {
                    MS.ShowMessage("The age can not be less 16");
                    b1 = false;
                }
                if (age >100)
                {
                    MS.ShowMessage("The age can not be more 100");
                    b1 = false;
                }
            } else
            {
                MS.ShowMessage("The age can not be equal or less zero");
                b1 = false;
            }
            if (gender == null)
            {
                MS.ShowMessage("The gender is not picked");
                b1 = false;
            }

            return b1;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName]string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }

        public bool? DialogResult
        {
            get { return dialogResult; }
            set
            {
                dialogResult = value;
                if (dialogResult == true)
                {
                    if (checkValues())
                    {
                        Student NWS = new Student { FirstName = firstName, Last = lastName, Age = age, Gender = gender };
                        if (act)
                        {
                            students.Add(NWS);
                        }
                        else
                        {
                            student.FirstName = firstName;
                            student.Last = lastName;
                            student.Age = age;
                            student.Gender = gender;
                        }
                    }
                }
            }
        }




    }
}
