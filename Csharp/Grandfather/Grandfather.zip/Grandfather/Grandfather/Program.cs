﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Grandfather
{
    class Program
    {
        static void Main(string[] args)
        {
            CalculateResult cl = new CalculateResult();
            Console.Write("Hello, Enter a weight of shugar that you need in order to brew moonshine\n");
            bool bl = false;
            string input = "";
            string s = ", ";
            int[] n;
            do
            {
                input = cl.GetInput();
                bl = cl.IsNumber(input);
                if (!bl)
                {
                    Console.Write("Iput is not correct, enter again, please\n");
                }

            } while (!bl);
            int Number = cl.GetNumber(input);
            Console.Write("Enter masses of bags with shugar that are in the shop.\n");
            do
            {
                input = cl.GetInput();
                n = cl.GetArray(input);
                if (n.Length == 0)
                {
                    Console.Write("Iput is not correct, enter again, please\n");
                }
            } while (n.Length == 0);
            input = cl.Checking(Number, n);
            Console.Write("Entered number is " + Number.ToString() + "\n");
            Console.Write("Entered array is ");
            for (int i = 0; i < n.Length; i++)
            {
                if (i == n.Length - 1)
                {
                    s = "\n";
                }
                Console.Write(n[i] + s);
            }
            if (input != "")
            {
                Console.Write("You should take bags with a weight: " + input);
            }
            else
            {
                Console.Write("There is not any way to take a necessary weight of shugar.\n");
          }
            Console.Write("Press any character to quit");
            Console.ReadKey();
        }
    }
    class CalculateResult
    {
        public string GetInput()
        {
            string input;
            input = Console.ReadLine();
            return input;
        }
        public bool IsNumber(string str)
        {
            int value;
            bool bl = Int32.TryParse(str, out value);
            if (!bl || value == 0)
            {
                return false;
            }
            else
            {
                return bl;
            }
        }
        public int GetNumber(string str)
        {
            int Number;
            bool bl = Int32.TryParse(str, out Number);
            return Number;
        }
        public int[] GetArray(string str)
        {
            int[] n = str.Split(' ', ',', '.', ';').Select(e => GetNumber(e)).ToArray();
            n = n.Where(x => x != 0).ToArray();
            return n;
        }
        public string Checking(int num, int[] arr)
        {
            List<string> options = new List<string>();
            string result = "";//строковая переменная для годного результата
            int min = 0; //минимум при отсутствии совпадений
            bool bl = true;
            for (int i = 0; i < arr.Length - 1; i++) //перебор вариантов из массива весов
            {
                for (int j = 0; j < arr.Length - 1; j++)
                {
                    int sum = arr[i] + arr[j];
                    if (sum == num)
                    {
                        if (arr[i] < arr[j]) //сортировка по возрастанию
                        {
                            result = arr[i].ToString() + " " + arr[j].ToString() + "; ";
                        }
                        else //сортировка по возрастанию
                        {
                            result = arr[j].ToString() + " " + arr[i].ToString() + "; ";
                        }
                        for (int d = 0; d < options.Count; d++) //проверяем нет ли уже этого значения в списке 
                        {
                            if (options[d] == result)
                                bl = false;
                        }
                        if (bl == true)
                            options.Add(result);
                    }
                    else //не сопвпала сумма
                    {
                        if (sum > num)
                        {
                            if (bl == false)
                            {
                                if (min == 0)
                                {
                                    min = sum;
                                }
                                else
                                {
                                    if (sum < min)
                                        min = sum;
                                }
                            }
                        }
                    }
                }
            }
            if (options.Count != 0)
            {
                result = "";
                for (int t = 0; t < options.Count; t++)
                {
                    result = result + options[t].ToString();
                }
                return result;
            }
            else
            {
                return result;
            }

        }
    }
}
