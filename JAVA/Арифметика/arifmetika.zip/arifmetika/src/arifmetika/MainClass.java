package arifmetika;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
		int size; 
		int[] arr; 
		int min = 0;
		int max = 0;
		int posMin = 0;
		int posMax = 0;
		int sym = 0;
		boolean counter = false;
		int mnoz = 0;
		
		System.out.println("������� ������ �������");
		size = sc.nextInt();
		
		arr = new int[size];
		
		for (int i = 0; i<size; i++)
		{
			System.out.println("������� ������� ������� � " + (i+1));
			arr[i] = sc.nextInt();
			
			if (arr[i]>0)
			{
				sym += arr[i];
			}
			
			if (i == 0)
			{
				min = arr[i];
				max = arr[i];
				posMin = 0;
			} else
			{
				if (arr[i] > max)
				{
					max = arr[i];
					posMax = i;
				}
				if (arr[i] < min)
				{
					min = arr[i];
					posMin = i;
				}
				
			}
		}
		
		if (posMin < posMax)
		{
			for (int i = posMin + 1; i < posMax; i++)
			{
				if (counter)
				{
					mnoz = mnoz*arr[i];
				} else
				{
					mnoz = arr[i];
					counter = true;
				}

			}
		} else
		{
			for (int i = posMax + 1; i < posMin; i++)
			{
				if (counter)
				{
					mnoz = mnoz*arr[i];
				} else
				{
					mnoz = arr[i];
					counter = true;
				}
			}
		}
		
		System.out.println("" + sym + " " + mnoz);
		
	}

}
