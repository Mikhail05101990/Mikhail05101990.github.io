package school;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		
		int size; 
		int[] arr; 
		String a1 = "";
		String b1 = "";		
		int free = 0; 
		int four = 0;
		
		System.out.println("������� ������ �������");
		size = sc.nextInt();
		
		arr = new int[size];
		
		for (int i = 0; i<size; i++)
		{
			System.out.println("������� ������� ������� � " + (i+1));
			arr[i] = sc.nextInt();
		}
		
		for (int i = 0; i<size; i++)
		{
			if (arr[i]%2 !=0)
			{
				if (a1.length() != 0)
				{
					a1 += " ";
				}
				a1 += arr[i];
				free++;
			} else
			{
				if (b1.length() != 0)
				{
					b1 += " ";
				}
				b1 += arr[i];
				four++;
			}
		}
		
		System.out.println(a1);
		System.out.println(b1);
		if (free<=four)
		{
			System.out.println("YES");
		} else
		{
			System.out.println("NO");
		}
		
		
		
		
	}

}
