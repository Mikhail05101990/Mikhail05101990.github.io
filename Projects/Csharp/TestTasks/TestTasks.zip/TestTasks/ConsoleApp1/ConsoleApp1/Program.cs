﻿using System;
using System.Linq;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            CalculateResult cl = new CalculateResult();
            Console.Write("Hello, Enter a number\n");
            bool bl = false;
            string input = "";
            string s = ", ";
            int[] n;
            do
            {
                input = cl.GetInput();
                bl = cl.IsNumber(input);
                if (!bl)
                {
                    Console.Write("Iput is not correct, enter again, please\n");
                }

            } while (!bl);
            int Number = cl.GetNumber(input);
            Console.Write("Enter an array\n");
            do
            {
                input = cl.GetInput();
                n = cl.GetArray(input);
                if (n.Length == 0)
                {
                    Console.Write("Iput is not correct, enter again, please\n");
                }
            } while (n.Length == 0);
            bl = cl.Checking(Number, n);
            Console.Write("Enterd number is " + Number.ToString() + "\n");
            Console.Write("Enterd array is ");
            for (int i = 0; i < n.Length; i++)
            {
                if (i == n.Length -1)
                {
                    s = "\n";
                }
                Console.Write(n[i] + s);
            }
            if (bl)
            {
                Console.Write("Yes\n");
            } else
            {
                Console.Write("No\n");
            }
            Console.Write("Press any character to quit");
            Console.ReadKey();
        }

        class CalculateResult
        {
            public string GetInput()
            {
                string input;
                input = Console.ReadLine();
                return input;
            }
            public bool IsNumber(string str)
            {
                int value;
                bool bl = Int32.TryParse(str, out value);
                if (!bl || value == 0)
                {
                    return false;
                } else
                {
                    return bl;
                }
            }
            public int GetNumber(string str)
            {
                int Number;
                bool bl = Int32.TryParse(str, out Number);
                return Number;
            }
            public int[] GetArray(string str)
            {
                int[] n = str.Split(' ', ',', '.', ';').Select(e => GetNumber(e)).ToArray();
                n = n.Where(x => x != 0).ToArray();
                return n;
            }
            public bool Checking(int num, int[] arr)
            {
                double res = num;
                for (int i = 0; i <arr.Length; i++)
                {
                    res = res / arr[i];
                }
                if (res != 1)
                {
                    return false;
                } else
                {
                    return true;
                }
            }
        }





    }
}
